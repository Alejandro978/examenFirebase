package ejHibernate;

import java.util.Date;

import org.hibernate.Session;

public class Programa {

	public static void main(String[] args) {
anyadirFestival();

	
	}

	public static void anyadirFestival() {
		Session session = HibernateUtilities.getSessionFactory().openSession();
		session.beginTransaction();
		festival f1 = new festival();
		f1.setIdFestival(1);
		f1.setNombre("Medusa");
		f1.setLugar("Cullera");
		f1.setFecha(new Date());
		session.save(f1);

		session.getTransaction().commit();
		session.close();
	}

	public static void anyadirActuacion() {
		Session session = HibernateUtilities.getSessionFactory().openSession();
		session.beginTransaction();
		actuacion ac1 = new actuacion();

		ac1.setHora("00:00");
		ac1.setEscenario("Escenario principal");

		session.save(ac1);

		
		session.getTransaction().commit();
		session.close();
	}

	public static void anyadirGrupo() {
		Session session = HibernateUtilities.getSessionFactory().openSession();
		session.beginTransaction();
		grupo g1 = new grupo();

		g1.setNombre("AC/DC");
		g1.setEstilo("Roock");
		g1.setNumMiembros(6);

		session.save(g1);

		
		session.getTransaction().commit();
		session.close();
	}

	public static void recuperarFestival() {
		Session session = HibernateUtilities.getSessionFactory().openSession();
		session.beginTransaction();
		festival f1 = session.get(festival.class,1);

		System.out.println("Festival: : " + f1.getNombre()+ " fecha " + f1.getFecha() + " en "+f1.getLugar());

		
		session.getTransaction().commit();
		session.close();
	}

	public static void recuperarActuacion() {
		Session session = HibernateUtilities.getSessionFactory().openSession();
		session.beginTransaction();
		actuacion ac1 = session.get(actuacion.class, 1);
	

		System.out.println("Hora " + ac1.getHora() + " el escenario es : " + ac1.getEscenario());

	
		session.getTransaction().commit();
		session.close();
	}
	
	public static void recuperarGrupo() {
		Session session = HibernateUtilities.getSessionFactory().openSession();
		session.beginTransaction();
		grupo g1 = session.get(grupo.class,1);

		System.out.println("Nombre grupo: " +g1.getNombre() + " estilo "+  g1.getEstilo() + " miebros : "+ g1.getNumMiembros());

		
		session.getTransaction().commit();
		session.close();
	}

}
