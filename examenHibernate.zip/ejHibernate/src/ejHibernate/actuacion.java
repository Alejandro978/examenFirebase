package ejHibernate;

public class actuacion {
	
public int idActuacion;
public String hora;
public String escenario;
public actuacion() {}

public actuacion(int idActuacion, String hora, String escenario) {

	this.idActuacion = idActuacion;
	this.hora = hora;
	this.escenario = escenario;
}


public int getIdActuacion() {
	return idActuacion;
}

public void setIdActuacion(int idActuacion) {
	this.idActuacion = idActuacion;
}

public String getHora() {
	return hora;
}

public void setHora(String hora) {
	this.hora = hora;
}

public String getEscenario() {
	return escenario;
}

public void setEscenario(String escenario) {
	this.escenario = escenario;
}







}
