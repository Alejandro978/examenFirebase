package ejHibernate;

public class grupo {
	
public int idGrupo;
public String nombre;
public String estilo;
public int numMiembros;

public grupo() {}

public int getIdGrupo() {
	return idGrupo;
}

public void setIdGrupo(int idGrupo) {
	this.idGrupo = idGrupo;
}

public String getNombre() {
	return nombre;
}

public void setNombre(String nombre) {
	this.nombre = nombre;
}

public String getEstilo() {
	return estilo;
}

public void setEstilo(String estilo) {
	this.estilo = estilo;
}

public int getNumMiembros() {
	return numMiembros;
}

public void setNumMiembros(int numMiembros) {
	this.numMiembros = numMiembros;
}

public grupo(int idGrupo, String nombre, String estilo, int numMiembros) {
	
	this.idGrupo = idGrupo;
	this.nombre = nombre;
	this.estilo = estilo;
	this.numMiembros = numMiembros;
}





}
