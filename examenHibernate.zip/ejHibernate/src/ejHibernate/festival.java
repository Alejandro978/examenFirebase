package ejHibernate;

import java.util.Date;

public class festival {
	
	public int idFestival;
	public String nombre;
	public String lugar;
	public Date fecha;
	
public festival () {}
	
public festival(int idFestival, String nombre, String lugar, Date fecha) {
	
	this.idFestival = idFestival;
	this.nombre = nombre;
	this.lugar = lugar;
	this.fecha = fecha;
}
	public int getIdFestival() {
		return idFestival;
	}

	public void setIdFestival(int idFestival) {
		this.idFestival = idFestival;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getLugar() {
		return lugar;
	}

	public void setLugar(String lugar) {
		this.lugar = lugar;
	}

	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}


	
	
	
}
